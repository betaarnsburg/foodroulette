package org.example.randomrezept;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomRezeptApplicationTests {

    @Test
    void contextLoads() {
    }

}
